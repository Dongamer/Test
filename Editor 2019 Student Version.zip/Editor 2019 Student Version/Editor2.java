public class Editor2
{
   private String str;
   private int slice;
   
   public Editor2( String _str, int index )
   {
       str = _str;
       slice = index;
   }
   
   public String toString()
   {
       return str.substring( 0, slice ) + "||" + str.substring( slice );
   }
   
   public String getBefore() { return str.substring( 0, slice );  }
   public String getAfter()  { return str.substring( slice ); }
   
   // working example that needs error case to be finished
   public Editor2 rightArrow()
   {
       return new Editor2( str, slice + 1 );
   }
   public Editor2 leftArrow()
   {
       return new Editor2( "notfinished", 3 );
   }
   public Editor2 delete()
   {
       return new Editor2( "notfinished", 3 );
   }
   public Editor2 backspace()
   {
       return new Editor2( "notfinished", 3 );
   }
   public Editor2 insertString(String c)  // Originally insert(char c), which is fine if you teach the char type
   {
       return new Editor2( "notfinished", 3 );
   }
   public Editor2 homeKey()
   {
       return new Editor2( "notfinished", 3 );
   }
   
   public Editor2 endKey()
   {
       return new Editor2( "notfinished", 3 );
   }
    
   public static void main( String [] args )
   {
       Editor2 eddie = new Editor2( "bigdog", 3 );
       System.out.println( eddie + " right arrow = " + eddie.rightArrow() );
       System.out.println( eddie + " left arrow = " + eddie.leftArrow() );       
   }
}
