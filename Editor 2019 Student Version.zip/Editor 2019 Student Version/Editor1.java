public class Editor1 
{
   private String pre, post;
   
   public Editor1( String before, String after )
   {
       pre = before;
       post = after;
   }
   
   public String toString()
   {
       return pre + "||" + post;
   }
   
   public String getBefore() { return pre;  }
   public String getAfter()  { return post; }
   
   public Editor1 rightArrow()
   {
       if( post.equals("" ) )
         return this;
       return new Editor1( pre + post.substring(0,1) , 
                           post.substring(1) );
   }
   
   public Editor1 leftArrow()
   {
       return new Editor1( "not", "finished" );
   }
   
   public Editor1 delete()
   {
       return new Editor1( "not", "finished" );
   }
   
   public Editor1 backspace()
   {
       return new Editor1( "not", "finished" );
   }
   
   public Editor1 insertString(String c)  // Originally insert(char c), which is fine if you teach the char type
   {
       return new Editor1( "not", "finished" );
   }
   
   public Editor1 homeKey()
   {
       return new Editor1( "not", "finished" );
   }
   
   public Editor1 endKey()
   {
       return new Editor1( "not", "finished" );
   }
    
   public static void main( String [] args )
   {
       // The following are four test cases for this problem.  
       Editor1 bothPrePost = new Editor1( "big", "dog" );
       Editor1 preOnly = new Editor1("big", "");
       Editor1 postOnly = new Editor1("", "dog");
       Editor1 neither = new Editor1("", ""); 
       
       System.out.println( bothPrePost + " right arrow = " + bothPrePost.rightArrow() );
       System.out.println( preOnly + " right arrow = " + preOnly.rightArrow() );
       System.out.println( postOnly + " right arrow = " + postOnly.rightArrow() );
       System.out.println( neither + " right arrow = " + neither.rightArrow() );        
   }
}
